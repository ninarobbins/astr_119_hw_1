x = 9
y = 3

print(x+y)
print(x-y)
print(x*y)
print(x/y)
print(x%y) #remainder or modulus
print(x//y) #floor division
print(x**y) #exponentiation

x = 9
x+=3
print(x)
x=9
x-=3
print(x)
x*=3
print(x)
x/=3
print(x)
x**=3
print(x)

#comparison True/False
x=9
y=3
print(x==y)
print(x!=y)
print(x>y)
print(x<y)
print(x>=y)
print(x<=y)
