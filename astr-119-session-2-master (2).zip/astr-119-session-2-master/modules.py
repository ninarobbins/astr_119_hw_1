import numpy as np
import matplotlib as plt
import sys #C-like library
import os #gives access to operating system

print(sys.argv) #prints any command line arguments, incl program name
print(os.getcwd()) #prints current working directory