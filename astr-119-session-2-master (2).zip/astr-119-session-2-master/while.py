i = 0

while (i<119):
	print(i)
	i += 10